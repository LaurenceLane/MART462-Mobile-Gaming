-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here


local tapCount = 0

local background = display.newImageRect( "background.png", 360, 570 )
background.x = display.contentCenterX
background.y = display.contentCenterY

local physics = require( "physics" )
physics.start()


local tapText = display.newText( tapCount, display.contentCenterX, 20, native.systemFont, 40 )
tapText:setFillColor( 0, 0, 0 )



local player = display.newImageRect( "EsterChibiFloat.png", 112, 112 )
player.x = display.contentCenterX
player.y = display.contentCenterY

physics.addBody( player, "dynamic", { radius=50, bounce=0.3 } )

local function pushplayer()
    player:applyLinearImpulse( 0, -0.75, player.x, player.y )
end

player:addEventListener( "tap", pushplayer )

local function pushplayer()
    player:applyLinearImpulse( 0, -0.75, player.x, player.y )
    tapCount = tapCount + 1
    tapText.text = tapCount
end

if
    player.y < 0 then
        tapCount = 0
        player.y = 112

    end

--function load()
  --  player = {}
    --player.x = 200
    --player.y = 100
--end
-----
---function update(dt)
  --  if keyboard.isDown("right") then
  --  player.x = player.x + 10
  --  end

    --if keyboard.isDown("left") then
     --   player.x = player.x - 10
    --end
    --end